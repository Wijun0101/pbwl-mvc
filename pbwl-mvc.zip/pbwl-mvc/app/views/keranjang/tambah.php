<h2>Tambah Keranjang</h2>

<form action="Proses" method="post">
    <table>
        <tr>
            <td>ID USER</td>
            <td><input type="text" name="ker_id_user"></td>
        </tr>
        <tr>
            <td>ID PRODUK</td>
            <td><input type="text" name="ker_id_produk"></td>
        </tr>
        <tr>
            <td>HARGA</td>
            <td><input type="text" name="ker_harga"></td>
        </tr>
        <tr>
            <td>JUMLAH</td>
            <td><input type="text" name="ker_jml"></td>
        </tr>
        
        <tr>
            <td></td>
            <td><input type="submit" name="btn_simpan" value="SIMPAN"></td>
        </tr>
    </table>
</form>