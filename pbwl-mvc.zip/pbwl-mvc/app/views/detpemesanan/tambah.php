<h2>Tambah Detail Pemesanan</h2>

<form action="Proses" method="post">
    <table>
        <tr>
            <td>ID ORDER</td>
            <td><input type="text" name="detail_id_order"></td>
        </tr>
        <tr>
            <td>ID PRODUK</td>
            <td><input type="text" name="detail_id_produk"></td>
        </tr>
        <tr>
            <td>HARGA</td>
            <td><input type="text" name="detail_harga"></td>
        </tr>
        <tr>
            <td>JUMLAH</td>
            <td><input type="text" name="detail_jml"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_simpan" value="SIMPAN"></td>
        </tr>
    </table>
</form>