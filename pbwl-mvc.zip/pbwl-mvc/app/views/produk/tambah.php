<h2>Tambah Produk</h2>

<form action="Proses" method="post">
    <table>
        <tr>
            <td>ID KATEGORI</td>
            <td><input type="text" name="produk_id_kat"></td>
        </tr>
        <tr>
            <td>ID USER</td>
            <td><input type="text" name="produk_id_user"></td>
        </tr>
        <tr>
            <td>KODE</td>
            <td><input type="text" name="produk_kode"></td>
        </tr>
        <tr>
            <td>NAMA</td>
            <td><input type="text" name="produk_nama"></td>
        </tr>
        <tr>
            <td>HARGA</td>
            <td><input type="text" name="produk_hrg"></td>
        </tr>
        <tr>
            <td>KETERANGAN</td>
            <td><input type="text" name="produk_keterangan"></td>
        </tr>
        <tr>
            <td>STOCK</td>
            <td><input type="text" name="produk_stock"></td>
        </tr>
        <tr>
            <td>PHOTO</td>
            <td><input type="text" name="produk_photo"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_simpan" value="SIMPAN"></td>
        </tr>
    </table>
</form>