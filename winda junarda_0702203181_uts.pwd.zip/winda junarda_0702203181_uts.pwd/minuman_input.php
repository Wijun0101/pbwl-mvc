<h2>Tambah Minuman</h2>

<form action="minuman_proses.php" method="post">
    <table>

        <tr>
            <td>Nama Minuman</td>
            <td><input type="text" name="nama_minuman"></td>
        </tr>
        <tr>
            <td>Harga Minuman</td>
            <td><input type="text" name="hrg_minuman"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_simpan" value="SIMPAN"></td>
        </tr>
    </table>
</form>

<a href="minuman_tampil.php">Kembali</a>