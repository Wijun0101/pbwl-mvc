<h2>Tambah Snack</h2>

<form action="snack_proses.php" method="post">
    <table>

        <tr>
            <td>Nama Snack</td>
            <td><input type="text" name="nama_snack"></td>
        </tr>
        <tr>
            <td>Harga Snack</td>
            <td><input type="text" name="hrg_snack"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_simpan" value="SIMPAN"></td>
        </tr>
    </table>
</form>

<a href="snack_tampil.php">Kembali</a>