<h2>Home</h2>

<div class="info">Selamat datang, <strong>DI MIE AYAM HAJI MAHMUD</strong></div>
<img src="layouts/assets/img/Mieayamhajimahmud.jpg" alt="">